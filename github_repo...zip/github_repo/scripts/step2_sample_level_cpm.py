#!/usr/bin/env python3
"""Step 2 (Python version used for the reported results): sample-level CPM and detection flags.
Usage: python step2_sample_level_cpm.py DATA_DIR master_sample_site_map.csv OUT_DIR
Equivalent R version: step2_master_table.R (not executed in the analysis environment)."""
import sys, pandas as pd
D, SMAP, OUT = sys.argv[1] + "/", sys.argv[2], sys.argv[3] + "/"
m = pd.read_csv(D + "meta.tsv", sep="\t"); b = pd.read_csv(D + "bacterial_read_df.tsv", sep="\t")
r = pd.read_csv(D + "rgi_bowtie.tsv", sep="\t", low_memory=False)
sm = pd.read_csv(SMAP)[["sample_code", "site", "Run", "BioSample"]]
idc = "Reference Allele(s) Identity to CARD Reference Protein (%)"
x = r[r[idc] >= 90].groupby(["fileName", "ARO Term", "Drug Class"], as_index=False)["All Mapped Reads"].sum().rename(columns={"All Mapped Reads": "all_mapped_reads"})
x = x.merge(b[["fileName", "total_reads"]], on="fileName")
x["cpm"] = x.all_mapped_reads / x.total_reads * 1e6; x["detected"] = x.cpm > 10     # strictly above 10 CPM, as in the source code
x = x.merge(m, left_on="fileName", right_on="sample_code").merge(sm, on="sample_code").drop(columns="sample_code")
x.to_csv(OUT + "step2_sample_level_cpm.csv", index=False)
s = x.groupby(["fileName", "city_state", "month_label", "site"], as_index=False).apply(
    lambda g: pd.Series({"n_aro_detected": int(g.detected.sum()), "retained_cpm_total": g.loc[g.detected, "cpm"].sum()}), include_groups=False)
s["retained_signal"] = s.n_aro_detected > 0
s.to_csv(OUT + "step2_sample_summary.csv", index=False)
print(len(x), int(x.detected.sum()), x.loc[x.detected, "ARO Term"].nunique(), int(s.retained_signal.sum()), len(s))
