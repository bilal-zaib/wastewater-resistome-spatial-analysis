#!/usr/bin/env python3
"""
Step 3 - primary analyses A, B, C exactly as specified in protocol v1.1 (frozen 26 Oct 2026).
Input : step2_sample_level_cpm.csv (from Step 2)
Output: step3_*.csv in the same folder. Fixed seed 20261024.
Sensitivity runs (protocol Section 8) are NOT in this script; they follow separately.
"""
import sys, numpy as np, pandas as pd
SEED = 20261024
NPERM_PERMANOVA, NPERM_DISP, NRESAMPLE = 9999, 4999, 1000
IN = sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/outputs/step2_sample_level_cpm.csv"
OUT = sys.argv[2] if len(sys.argv) > 2 else "/mnt/user-data/outputs/"
rng = np.random.default_rng(SEED)

x = pd.read_csv(IN, usecols=["fileName","Drug Class","all_mapped_reads","total_reads","cpm","detected","city_state","month_label","site"])
samples = x.drop_duplicates("fileName")[["fileName","city_state","month_label","site","total_reads"]].reset_index(drop=True)
det = x[x.detected].copy()
# source convention (main.R lines 506-521): an ARO with more than one drug class is labelled 'multidrug'
det["cls"] = np.where(det["Drug Class"].str.contains(";"), "multidrug", det["Drug Class"])
sc = det.groupby(["fileName","cls"], as_index=False)["cpm"].sum()
M = sc.pivot(index="fileName", columns="cls", values="cpm").reindex(samples.fileName).fillna(0.0)
classes = list(M.columns)
samples["retained"] = M.sum(axis=1).values > 0
print(f"samples {len(samples)} | classes {len(classes)} | no retained signal: {list(samples.fileName[~samples.retained])}")

def bray(P):
    return np.abs(P[:, None, :] - P[None, :, :]).sum(2) / (P[:, None, :] + P[None, :, :]).sum(2)

def restricted_perm(labels, blocks_idx):
    p = labels.copy()
    for idx in blocks_idx:
        if len(idx) > 1:
            p[idx] = rng.permutation(labels[idx])
    return p

def pseudo_F(D2, lab, a, N):
    G = np.eye(a)[lab]; n = G.sum(0)
    within = ((G * (D2 @ G)).sum(0) / (2 * n)).sum()
    sst = D2.sum() / (2 * N)
    return ((sst - within) / (a - 1)) / (within / (N - a)), (sst - within) / sst

def disp_F(X, Y, lab, a, N):
    G = np.eye(a)[lab]; n = G.sum(0)
    C = (G.T @ X) / n[:, None]; Cn = (G.T @ Y) / n[:, None]
    z = np.sqrt(np.abs(((X - G @ C) ** 2).sum(1) - ((Y - G @ Cn) ** 2).sum(1)))
    zg = (G.T @ z) / n
    ssb = (n * (zg - z.mean()) ** 2).sum(); ssw = ((z - G @ zg) ** 2).sum()
    return (ssb / (a - 1)) / (ssw / (N - a))

# ---------------- Analysis A: PERMANOVA by site within city, permutations restricted within month ----------------
rowsA = []
for city, s in samples[samples.retained].groupby("city_state"):
    s = s.reset_index(drop=True)
    P = M.loc[s.fileName].values; P = P / P.sum(1, keepdims=True)
    D = bray(P); D2 = D ** 2; N = len(s)
    sites = sorted(s.site.unique()); a = len(sites)
    lab = s.site.map({k: i for i, k in enumerate(sites)}).values
    blocks = [np.where(s.month_label.values == m)[0] for m in s.month_label.unique()]
    blocks_valid = [b for b in blocks if len(set(lab[b])) > 1]
    F0, R2 = pseudo_F(D2, lab, a, N)
    cnt = 0
    for _ in range(NPERM_PERMANOVA):
        Fp, _r = pseudo_F(D2, restricted_perm(lab, blocks), a, N); cnt += Fp >= F0
    pA = (1 + cnt) / (1 + NPERM_PERMANOVA)
    # dispersion (PERMDISP) on the PCoA of the same distance matrix
    J = np.eye(N) - 1.0 / N; B = -0.5 * J @ D2 @ J
    w, V = np.linalg.eigh(B); pos = w > 1e-10; neg = w < -1e-10
    X = V[:, pos] * np.sqrt(w[pos]); Y = V[:, neg] * np.sqrt(-w[neg])
    Fd0 = disp_F(X, Y, lab, a, N); cd = 0
    for _ in range(NPERM_DISP):
        cd += disp_F(X, Y, restricted_perm(lab, blocks), a, N) >= Fd0
    pD = (1 + cd) / (1 + NPERM_DISP)
    rowsA.append(dict(city=city, samples=N, sites=a, months_with_valid_permutation=len(blocks_valid),
                      pseudo_F=F0, R2=R2, p_perm=pA, permdisp_F=Fd0, permdisp_p=pD))
A = pd.DataFrame(rowsA)
# Benjamini-Hochberg over the four city-specific primary p-values
o = np.argsort(A.p_perm.values); m = len(A); adj = np.empty(m)
q = A.p_perm.values[o] * m / (np.arange(m) + 1); q = np.minimum.accumulate(q[::-1])[::-1]; adj[o] = np.minimum(q, 1)
A["p_BH"] = adj
A.to_csv(OUT + "step3_A_permanova_by_city.csv", index=False)
print("\nA: PERMANOVA by site (restricted within month)\n", A.round(4).to_string(index=False))

# ---------------- Analysis B: pooled vs equal-site city-month estimates ----------------
S = samples.set_index("fileName")
def cm_groups():
    for (city, mon), g in samples.groupby(["city_state","month_label"]):
        if g.site.nunique() >= 2:
            yield city, mon, g
rowsB, diffs = [], []
for city, mon, g in cm_groups():
    cpm = M.loc[g.fileName].values                      # sites x classes (CPM per site)
    tot = g.total_reads.values
    mapped = cpm * tot[:, None] / 1e6                   # mapped reads of detected ARGs per class
    pooled = mapped.sum(0) / tot.sum() * 1e6
    eqm, eqd = cpm.mean(0), np.median(cpm, 0)
    rk = pd.DataFrame({"p": pooled, "e": eqm}).rank().corr().iloc[0, 1]
    top = lambda v: set(np.argsort(-v, kind="stable")[:3])
    pp, ee = pooled / pooled.sum() if pooled.sum() else pooled, eqm / eqm.sum() if eqm.sum() else eqm
    rowsB.append(dict(city=city, month=mon, sites=len(g), spearman=rk, top3_same=top(pooled) == top(eqm),
                      top1_same=int(np.argmax(pooled) == np.argmax(eqm)),
                      rel_L1_diff=np.abs(pooled - eqm).sum() / pooled.sum() if pooled.sum() else np.nan,
                      bray_profile=0.5 * np.abs(pp - ee).sum(), pooled_total=pooled.sum(), eqsite_total=eqm.sum(),
                      eqsite_median_vs_mean_rel=np.abs(eqd - eqm).sum() / eqm.sum() if eqm.sum() else np.nan))
    diffs.append(pd.DataFrame({"city": city, "month": mon, "cls": classes, "diff": pooled - eqm}))
B = pd.DataFrame(rowsB); B.to_csv(OUT + "step3_B_aggregation_citymonth.csv", index=False)
Bs = B.groupby("city").agg(city_months=("month", "size"), spearman_median=("spearman", "median"),
        spearman_q25=("spearman", lambda v: v.quantile(.25)), spearman_q75=("spearman", lambda v: v.quantile(.75)),
        top3_differ_pct=("top3_same", lambda v: 100 * (1 - v.mean())), top1_differ_pct=("top1_same", lambda v: 100 * (1 - v.mean())),
        rel_L1_median=("rel_L1_diff", "median"), bray_profile_median=("bray_profile", "median")).reset_index()
Bs.to_csv(OUT + "step3_B_summary_by_city.csv", index=False)
d = pd.concat(diffs); dc = d.groupby("cls")["diff"].agg(median="median", q25=lambda v: v.quantile(.25), q75=lambda v: v.quantile(.75)).reset_index()
dc.to_csv(OUT + "step3_B_class_difference_summary.csv", index=False)
print("\nB: aggregation (pooled vs equal-site), city-months with >=2 sites\n", Bs.round(3).to_string(index=False))

# ---------------- Analysis C: two-site stability (cities with more than two sites) ----------------
rowsC = []
for city, g0 in samples.groupby("city_state"):
    if g0.site.nunique() <= 2:
        rowsC.append(dict(city=city, city_months=0, note="only two sites: resampling not meaningful (limitation)")); continue
    dist, match, skipped, ncm = [], [], 0, 0
    for mon, g in g0.groupby("month_label"):
        if len(g) < 3: continue
        ncm += 1; cpm = M.loc[g.fileName].values; full = cpm.mean(0)
        full_p = full / full.sum(); topf = set(np.argsort(-full, kind="stable")[:3])
        for _ in range(NRESAMPLE):
            pick = rng.choice(len(g), 2, replace=False); sub = cpm[pick].mean(0)
            if sub.sum() == 0: skipped += 1; continue
            dist.append(0.5 * np.abs(sub / sub.sum() - full_p).sum())
            match.append(set(np.argsort(-sub, kind="stable")[:3]) == topf)
    rowsC.append(dict(city=city, city_months=ncm, resamples=len(dist), skipped_zero_profile=skipped,
                      bray_median=np.median(dist), bray_p5=np.percentile(dist, 5), bray_p95=np.percentile(dist, 95),
                      top3_match_rate=np.mean(match)))
C = pd.DataFrame(rowsC); C.to_csv(OUT + "step3_C_two_site_stability.csv", index=False)
print("\nC: two-site stability\n", C.round(3).to_string(index=False))
