#!/usr/bin/env python3
"""
Step 1 (Days 1-2): provenance + metadata audit. Read-only on inputs.

Usage:
    python step1_audit.py INPUT_DIR OUTPUT_DIR

Put UNMODIFIED downloads in INPUT_DIR (Zenodo 10.5281/zenodo.17590646 files
and the SowpatiLab/Metro_metagenomics repo files). Never edit them.
Writes OUTPUT_DIR/step1_qc_report.md and OUTPUT_DIR/file_manifest.csv.
"""
import sys, hashlib, datetime, re
from pathlib import Path
import pandas as pd

EXPECTED_SAMPLES = 447
EXPECTED_SITES = {"Kolkata": 2, "Delhi": 4, "Chennai": 5, "Mumbai": 8}
KEY_FILES = ["meta.tsv", "rgi_bowtie.tsv", "bacterial_read_df.tsv"]


def sha256(p, chunk=1 << 20):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        while b := f.read(chunk):
            h.update(b)
    return h.hexdigest()


def read_table(p, nrows=None):
    sep = "\t" if p.suffix in (".tsv", ".txt") else ","
    return pd.read_csv(p, sep=sep, nrows=nrows, low_memory=False)


def main(inp, out):
    inp, out = Path(inp), Path(out)
    out.mkdir(parents=True, exist_ok=True)
    today = datetime.date.today().isoformat()
    lines = [f"# Step 1 QC report ({today})", ""]

    # 1. Manifest with checksums (provenance)
    rows = []
    for p in sorted(inp.rglob("*")):
        if p.is_file():
            rows.append({"file": str(p.relative_to(inp)), "bytes": p.stat().st_size,
                         "sha256": sha256(p), "accessed": today})
    pd.DataFrame(rows).to_csv(out / "file_manifest.csv", index=False)
    lines += [f"Files found: {len(rows)} (manifest: file_manifest.csv)", ""]
    present = {Path(r["file"]).name for r in rows}
    for k in KEY_FILES:
        lines.append(f"- {k}: {'FOUND' if k in present else 'MISSING'}")
    lines.append("")

    # 2. Inspect meta.tsv
    meta_path = next((p for p in inp.rglob("meta.tsv")), None)
    if meta_path is None:
        lines.append("**STOP: meta.tsv not found. Cannot assess site metadata.**")
        (out / "step1_qc_report.md").write_text("\n".join(lines))
        return
    meta = read_table(meta_path)
    lines += ["## meta.tsv", f"Rows: {len(meta)} (expected {EXPECTED_SAMPLES})",
              f"Columns: {list(meta.columns)}", ""]

    # Candidate columns (heuristic; YOU confirm against the data dictionary)
    cols = {c.lower(): c for c in meta.columns}
    def find(*pats):
        return [orig for low, orig in cols.items() if any(re.search(p, low) for p in pats)]
    key_c = find(r"sample", r"run", r"accession|srr|biosample")
    city_c = find(r"city")
    site_c = find(r"site", r"location", r"drain|spot|place")
    date_c = find(r"date", r"month", r"time")
    lines += [f"Candidate sample key columns: {key_c}",
              f"Candidate city columns: {city_c}",
              f"Candidate site/location columns: {site_c}",
              f"Candidate date/month columns: {date_c}", ""]

    # 3. Gate checks (only where candidates exist)
    if key_c:
        k = key_c[0]
        dup = meta[k].duplicated().sum()
        lines.append(f"Duplicate values in key '{k}': {dup}")
    if city_c:
        lines.append("Samples per city: " + str(meta[city_c[0]].value_counts().to_dict()))
    if city_c and site_c:
        s = meta.groupby(city_c[0])[site_c[0]].nunique().to_dict()
        lines.append(f"Sites per city found: {s} | expected: {EXPECTED_SITES}")
        site_n = meta.groupby([city_c[0], site_c[0]]).size()
        lines.append(f"Locations with >=6 samples: {(site_n >= 6).sum()} of {len(site_n)} (gate needs >=12)")
        miss = meta[site_c[0]].isna().mean()
        lines.append(f"Fraction missing site label: {miss:.1%} (gate needs <=10%)")
    else:
        lines.append("**No clear site column in meta.tsv. Check article supplement / BioSample next; do NOT infer sites from sample names.**")
    if date_c:
        lines.append(f"Fraction missing date/month: {meta[date_c[0]].isna().mean():.1%}")

    # 4. Key overlap with other tables
    if key_c:
        k = key_c[0]
        for name in ["rgi_bowtie.tsv", "bacterial_read_df.tsv"]:
            p = next((q for q in inp.rglob(name)), None)
            if p is None:
                continue
            t = read_table(p, nrows=5)
            lines += ["", f"## {name} (first columns): {list(t.columns)[:12]}"]
            for c in t.columns:
                if c.lower() in cols or "sample" in c.lower():
                    full = read_table(p)
                    ids = set(full[c].astype(str))
                    ov = len(ids & set(meta[k].astype(str)))
                    lines.append(f"Column '{c}': {len(ids)} unique ids, {ov} match meta key '{k}'")
                    break

    lines += ["", "## Your decision (fill in by hand)",
              "- GO / GO with limitation / STOP (see protocol Section 12): ______",
              "- Licence checked on Zenodo record and article: ______"]
    (out / "step1_qc_report.md").write_text("\n".join(lines))
    print("\n".join(lines))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
