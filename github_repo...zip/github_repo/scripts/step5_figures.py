#!/usr/bin/env python3
"""Step 5 - the four planned figures (protocol v1.1, Section 9). Seed 20261024."""
import sys, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
CPM = sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/outputs/step2_sample_level_cpm.csv"
STEP3 = sys.argv[2] if len(sys.argv) > 2 else "/mnt/user-data/outputs/"
OUT = sys.argv[3] if len(sys.argv) > 3 else "/mnt/user-data/outputs/pilot_package/figures/"
rng = np.random.default_rng(20261024)
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})
x = pd.read_csv(CPM, usecols=["fileName","Drug Class","cpm","detected","city_state","month_label","site","total_reads"])
S = x.drop_duplicates("fileName")[["fileName","city_state","month_label","site","total_reads"]].reset_index(drop=True)
d = x[x.detected].copy(); d["cls"] = np.where(d["Drug Class"].str.contains(";"), "multidrug", d["Drug Class"])
M = d.groupby(["fileName","cls"])["cpm"].sum().unstack(fill_value=0.0).reindex(S.fileName).fillna(0.0)
S["site"] = S.site.replace({"Kj Somaiya Ghatkopar": "KJ Somaiya Ghatkopar", "Lbs Marg, Bhandup": "LBS Marg, Bhandup"})  # restore acronym capitalisation
S["retained"] = M.sum(axis=1).values > 0
S["ym"] = pd.to_datetime(S.month_label, format="%m/%y")
cities = ["Chennai","Delhi","Kolkata","Mumbai"]; col = {"Chennai":"#0072B2","Delhi":"#D55E00","Kolkata":"#009E73","Mumbai":"#CC79A7"}

# ---- Figure 1: sampling coverage ----
sites = S.drop_duplicates("site").assign(c=lambda t: t.city_state.map({c:i for i,c in enumerate(cities)})).sort_values(["c","site"])
months = sorted(S.ym.unique()); grid = np.zeros((len(sites), len(months)))
for i, st in enumerate(sites.site):
    present = set(S[S.site == st].ym)
    grid[i] = [m in present for m in months]
fig, ax = plt.subplots(figsize=(8, 5.2))
ax.imshow(grid, cmap="Blues", aspect="auto", vmin=0, vmax=1.4)
ax.set_yticks(range(len(sites))); ax.set_yticklabels([f"{s}  ({c})" for s, c in zip(sites.site, sites.city_state)], fontsize=7)
ax.set_xticks(range(0, len(months), 3)); ax.set_xticklabels([pd.Timestamp(m).strftime("%b %y") for m in months][::3], rotation=45, ha="right")
for k in np.cumsum(sites.groupby("city_state", sort=False).size().reindex(cities).values)[:-1]: ax.axhline(k - .5, color="k", lw=.8)
ax.set_title("Sampling coverage: one sample per site-month (blank = not sampled)", fontsize=9)
plt.tight_layout(); plt.savefig(OUT + "Fig1_sampling_coverage.png", dpi=200); plt.savefig(OUT + "Fig1_sampling_coverage.pdf"); plt.close()

# ---- Figure 2: within-city ordination ----
A = pd.read_csv(STEP3 + "step3_A_permanova_by_city.csv").set_index("city")
def bray(P): return np.abs(P[:, None, :] - P[None, :, :]).sum(2) / (P[:, None, :] + P[None, :, :]).sum(2)
fig, axs = plt.subplots(2, 2, figsize=(8, 7))
for ax, city in zip(axs.ravel(), cities):
    g = S[(S.city_state == city) & S.retained].reset_index(drop=True)
    P = M.loc[g.fileName].values; P = P / P.sum(1, keepdims=True); D2 = bray(P) ** 2; N = len(g)
    J = np.eye(N) - 1 / N; w, V = np.linalg.eigh(-0.5 * J @ D2 @ J); o = np.argsort(w)[::-1]; w, V = w[o], V[:, o]
    X = V[:, :2] * np.sqrt(np.maximum(w[:2], 0)); ev = 100 * w[:2] / w[w > 0].sum()
    cmap = plt.get_cmap("tab10")
    for k, st in enumerate(sorted(g.site.unique())):
        m = (g.site == st).values; ax.scatter(X[m, 0], X[m, 1], s=16, color=cmap(k), label=st, alpha=.85, edgecolor="none")
    ax.set_xlabel(f"PCoA1 ({ev[0]:.0f}%)"); ax.set_ylabel(f"PCoA2 ({ev[1]:.0f}%)")
    ax.set_title(f"{city}: R\u00b2={A.loc[city,'R2']:.2f}, BH p={A.loc[city,'p_BH']:.3g}", fontsize=9)
    ax.legend(fontsize=5.5, frameon=False, loc="best", handletextpad=.2)
fig.suptitle("Within-city ARG-class composition by site (Bray-Curtis PCoA)", fontsize=9)
plt.tight_layout(); plt.savefig(OUT + "Fig2_site_ordination.png", dpi=200); plt.savefig(OUT + "Fig2_site_ordination.pdf"); plt.close()

# ---- Figure 3: pooled vs equal-site class CPM ----
rows = []
for (city, mon), g in S.groupby(["city_state","month_label"]):
    if g.site.nunique() < 2: continue
    cpm = M.loc[g.fileName].values; tot = g.total_reads.values
    pooled = (cpm * tot[:, None] / 1e6).sum(0) / tot.sum() * 1e6; eq = cpm.mean(0)
    rows.append(pd.DataFrame({"city": city, "pooled": pooled, "eqs": eq}))
R = pd.concat(rows); B = pd.read_csv(STEP3 + "step3_B_aggregation_citymonth.csv")
fig, axs = plt.subplots(1, 2, figsize=(8, 3.8), gridspec_kw={"width_ratios": [1.1, 1]})
for c in cities:
    t = R[R.city == c]; axs[0].scatter(np.log10(t.eqs + 1), np.log10(t.pooled + 1), s=5, alpha=.35, color=col[c], label=c, edgecolor="none")
lim = [0, max(np.log10(R.eqs + 1).max(), np.log10(R.pooled + 1).max()) * 1.03]; axs[0].plot(lim, lim, "k--", lw=.7)
axs[0].set_xlabel("Equal-site mean CPM, log10(x+1)"); axs[0].set_ylabel("Pooled CPM, log10(x+1)"); axs[0].legend(frameon=False, fontsize=7, markerscale=2)
axs[0].set_title("Class-level estimates, each city-month", fontsize=9)
axs[1].boxplot([100 * B[B.city == c].rel_L1_diff.dropna() for c in cities], tick_labels=cities, patch_artist=True,
               boxprops=dict(facecolor="#dddddd"), medianprops=dict(color="k"), flierprops=dict(markersize=3))
axs[1].set_ylabel("Relative difference, pooled vs equal-site (%)"); axs[1].set_title("Size of the aggregation effect", fontsize=9)
fig.suptitle("Pooling versus equal-site weighting (city-months with at least two sites)", fontsize=9)
plt.tight_layout(); plt.savefig(OUT + "Fig4_aggregation_comparison.png", dpi=200); plt.savefig(OUT + "Fig4_aggregation_comparison.pdf"); plt.close()

# ---- Figure 4: two-site stability (resamples regenerated with seed 20261024) ----
dist = {}
for city in ["Chennai","Delhi","Mumbai"]:
    vals = []
    for mon, g in S[S.city_state == city].groupby("month_label"):
        if len(g) < 3: continue
        cpm = M.loc[g.fileName].values; full = cpm.mean(0)
        if full.sum() == 0: continue
        fp = full / full.sum()
        for _ in range(1000):
            sub = cpm[rng.choice(len(g), 2, replace=False)].mean(0)
            if sub.sum() > 0: vals.append(0.5 * np.abs(sub / sub.sum() - fp).sum())
    dist[city] = np.array(vals)
C = pd.read_csv(STEP3 + "step3_C_two_site_stability.csv").set_index("city")
fig, ax = plt.subplots(figsize=(6, 3.8))
bp = ax.boxplot([dist[c] for c in dist], tick_labels=list(dist), patch_artist=True, showfliers=False, whis=(5, 95),
                medianprops=dict(color="k"))
for p, c in zip(bp["boxes"], dist): p.set_facecolor(col[c]); p.set_alpha(.7)
for i, c in enumerate(dist, 1): ax.text(i, ax.get_ylim()[1] * .96, f"top-3 match\n{100*C.loc[c,'top3_match_rate']:.0f}%", ha="center", va="top", fontsize=7)
ax.set_ylabel("Bray-Curtis distance, two-site vs all-site profile"); ax.set_title("Stability of two-site profiles (box = IQR, whiskers = 5th-95th percentile)", fontsize=8)
plt.tight_layout(); plt.savefig(OUT + "Fig5_two_site_stability.png", dpi=200); plt.savefig(OUT + "Fig5_two_site_stability.pdf"); plt.close()
print({c: (round(float(np.median(v)), 3), round(float(np.percentile(v, 95)), 3)) for c, v in dist.items()})
print(C[["bray_median", "bray_p95"]].round(3).to_dict())
