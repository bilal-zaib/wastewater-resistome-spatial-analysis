# Step 2 (protocol v1.1, Days 3-4): sample-level CPM, detection flags, source-filter check.
# Run in RStudio or a Google Colab R runtime. Reads inputs only; writes to OUT_DIR.
# No outcome (PERMANOVA, aggregation comparison) is computed here.
suppressPackageStartupMessages({library(readr); library(dplyr); library(tidyr)})

DATA_DIR <- "data"                           # folder holding meta.tsv, rgi_bowtie.tsv, bacterial_read_df.tsv
SITE_MAP <- "master_sample_site_map.csv"     # sample-to-site key (from NCBI SRA run table)
OUT_DIR  <- "step2_out"
dir.create(OUT_DIR, showWarnings = FALSE)

meta <- read_tsv(file.path(DATA_DIR, "meta.tsv"), show_col_types = FALSE)
bact <- read_tsv(file.path(DATA_DIR, "bacterial_read_df.tsv"), show_col_types = FALSE)
rgi  <- read_tsv(file.path(DATA_DIR, "rgi_bowtie.tsv"), show_col_types = FALSE)
smap <- read_csv(SITE_MAP, show_col_types = FALSE) %>% select(sample_code, site, Run, BioSample)

id_col <- "Reference Allele(s) Identity to CARD Reference Protein (%)"

# ---- 1. Integrity checks (printed; paste these back) ----
cat("\n== CHECKS ==\n")
cat("meta rows:", nrow(meta), "| unique sample_code:", n_distinct(meta$sample_code), "\n")
cat("rgi rows:", nrow(rgi), "| samples with rgi rows:", n_distinct(rgi$fileName), "\n")
cat("rgi rows not in meta:", sum(!rgi$fileName %in% meta$sample_code), "\n")
cat("samples missing from bacterial_read_df:", sum(!meta$sample_code %in% bact$fileName), "\n")
cat("min total_reads:", min(bact$total_reads), "| any total_reads <= 0:", any(bact$total_reads <= 0), "\n")
cat("rows per sample x ARO term (should be 1):", paste(names(table(rgi %>% count(fileName, `ARO Term`) %>% pull(n))), collapse = ","), "\n")
cat("rows with identity < 90:", sum(rgi[[id_col]] < 90), "\n")

# ---- 2. Sample-level CPM and detection flags (protocol Section 6) ----
sample_cpm <- rgi %>%
  filter(.data[[id_col]] >= 90) %>%
  group_by(fileName, `ARO Term`, `Drug Class`) %>%
  summarise(all_mapped_reads = sum(`All Mapped Reads`), .groups = "drop") %>%
  left_join(bact %>% select(fileName, total_reads), by = "fileName") %>%
  mutate(cpm = all_mapped_reads / total_reads * 1e6,
         detected = cpm > 10) %>%                      # strictly above 10 CPM, as in the source code
  left_join(meta, by = c("fileName" = "sample_code")) %>%
  left_join(smap, by = c("fileName" = "sample_code"))

write_csv(sample_cpm, file.path(OUT_DIR, "step2_sample_level_cpm.csv"))

sample_summary <- sample_cpm %>%
  group_by(fileName, city_state, month_label, site) %>%
  summarise(n_aro_detected = sum(detected),
            retained_cpm_total = sum(cpm[detected]), .groups = "drop") %>%
  mutate(retained_signal = n_aro_detected > 0)
write_csv(sample_summary, file.path(OUT_DIR, "step2_sample_summary.csv"))

cat("\nsample-ARO pairs:", nrow(sample_cpm), "| detected (>10 CPM):", sum(sample_cpm$detected), "\n")
cat("unique ARO detected in any sample:", n_distinct(sample_cpm$`ARO Term`[sample_cpm$detected]), "\n")
cat("samples with >=1 detected ARG:", sum(sample_summary$retained_signal), "of", nrow(sample_summary), "\n")
cat("samples with NO retained signal:", paste(sample_summary$fileName[!sample_summary$retained_signal], collapse = ", "), "\n")

# ---- 3. Reproduce the authors' pooled city-month filter (validation only) ----
den <- bact %>% left_join(meta, by = c("fileName" = "sample_code")) %>%
  group_by(city_state, month_label) %>% summarise(total_reads = sum(total_reads), .groups = "drop")
pooled <- rgi %>% filter(.data[[id_col]] >= 90) %>%
  left_join(meta, by = c("fileName" = "sample_code")) %>%
  group_by(city_state, month_label, `ARO Term`, `Drug Class`) %>%
  summarise(all_mapped_reads = sum(`All Mapped Reads`), .groups = "drop") %>%
  left_join(den, by = c("city_state", "month_label")) %>%
  mutate(cpm = all_mapped_reads / total_reads * 1e6) %>% filter(cpm > 10)
write_csv(pooled, file.path(OUT_DIR, "step2_source_pooled_replication.csv"))
cat("\nsource-style pooled rows:", nrow(pooled), "| unique ARO:", n_distinct(pooled$`ARO Term`), "\n")
cat("\nDone. Paste the printed CHECKS block back.\n")
