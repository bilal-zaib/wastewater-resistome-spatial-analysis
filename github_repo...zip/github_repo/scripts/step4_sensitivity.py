#!/usr/bin/env python3
"""
Step 4 - pre-specified sensitivity analyses (protocol v1.1, Section 8). Same methods as Step 3, one setting changed at a time.
Needs the extracted Zenodo tables (meta.tsv, rgi_bowtie.tsv, bacterial_read_df.tsv) and master_sample_site_map.csv.
PERMANOVA 4,999 permutations; PERMDISP 999; leave-one-site-out 1,999 (reduced from the primary 9,999/4,999 for speed; stated in the report).
"""
import sys, numpy as np, pandas as pd
D = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/data/data/"
SMAP = sys.argv[2] if len(sys.argv) > 2 else "/mnt/user-data/outputs/master_sample_site_map.csv"
OUT = sys.argv[3] if len(sys.argv) > 3 else "/mnt/user-data/outputs/"
SEED, SEED2 = 20261024, 20261025
NP_A, NP_D, NP_LO, NRES = 4999, 999, 1999, 1000

meta = pd.read_csv(D + "meta.tsv", sep="\t"); bact = pd.read_csv(D + "bacterial_read_df.tsv", sep="\t")
rgi = pd.read_csv(D + "rgi_bowtie.tsv", sep="\t", low_memory=False)
smap = pd.read_csv(SMAP)[["sample_code", "site"]]
IDC = "Reference Allele(s) Identity to CARD Reference Protein (%)"
base = meta.merge(smap, on="sample_code").merge(bact[["fileName", "total_reads"]], left_on="sample_code", right_on="fileName")
base = base.rename(columns={"sample_code": "fileName_"}).drop(columns="fileName").rename(columns={"fileName_": "fileName"})

def build(idt=90, thr=10, drop_low=False):
    f = rgi[rgi[IDC] >= idt].groupby(["fileName", "ARO Term", "Drug Class"], as_index=False)["All Mapped Reads"].sum()
    f = f.merge(bact[["fileName", "total_reads"]], on="fileName"); f["cpm"] = f["All Mapped Reads"] / f.total_reads * 1e6
    d = f[f.cpm > thr].copy(); d["cls"] = np.where(d["Drug Class"].str.contains(";"), "multidrug", d["Drug Class"])
    s = base.copy().rename(columns={"city_state": "city_state"})
    if drop_low:
        s = s[s.total_reads >= np.percentile(base.total_reads, 10)]
    M = d.groupby(["fileName", "cls"])["cpm"].sum().unstack(fill_value=0.0).reindex(s.fileName).fillna(0.0)
    s = s.reset_index(drop=True); s["retained"] = M.sum(1).values > 0
    return s, M

def bray(P): return np.abs(P[:, None, :] - P[None, :, :]).sum(2) / (P[:, None, :] + P[None, :, :]).sum(2)
def aitchison(P):
    z = P[P > 0].min() * 0.5; Q = np.where(P == 0, z, P); Q = Q / Q.sum(1, keepdims=True); L = np.log(Q); L = L - L.mean(1, keepdims=True)
    return np.sqrt(((L[:, None, :] - L[None, :, :]) ** 2).sum(2))
def rperm(rng, lab, blocks):
    p = lab.copy()
    for i in blocks:
        if len(i) > 1: p[i] = rng.permutation(lab[i])
    return p
def pF(D2, lab, a, N):
    G = np.eye(a)[lab]; n = G.sum(0); w = ((G * (D2 @ G)).sum(0) / (2 * n)).sum(); sst = D2.sum() / (2 * N)
    return ((sst - w) / (a - 1)) / (w / (N - a)), (sst - w) / sst
def dF(X, Y, lab, a, N):
    G = np.eye(a)[lab]; n = G.sum(0); C = (G.T @ X) / n[:, None]; Cn = (G.T @ Y) / n[:, None]
    z = np.sqrt(np.abs(((X - G @ C) ** 2).sum(1) - ((Y - G @ Cn) ** 2).sum(1))); zg = (G.T @ z) / n
    return ((n * (zg - z.mean()) ** 2).sum() / (a - 1)) / (((z - G @ zg) ** 2).sum() / (N - a))
def bh(p):
    p = np.array(p); o = np.argsort(p); m = len(p); q = p[o] * m / (np.arange(m) + 1); q = np.minimum.accumulate(q[::-1])[::-1]
    r = np.empty(m); r[o] = np.minimum(q, 1); return r

def analysisA(s, M, label, metric="bray", nperm=NP_A, nd=NP_D, with_disp=True, only_city=None):
    rng = np.random.default_rng(SEED); rows = []
    for city, g in s[s.retained].groupby("city_state"):
        if only_city and city != only_city: continue
        g = g.reset_index(drop=True); a = g.site.nunique()
        if a < 2: continue
        P = M.loc[g.fileName].values; P = P / P.sum(1, keepdims=True)
        Dm = bray(P) if metric == "bray" else aitchison(P); D2 = Dm ** 2; N = len(g)
        sites = sorted(g.site.unique()); lab = g.site.map({k: i for i, k in enumerate(sites)}).values
        blocks = [np.where(g.month_label.values == m)[0] for m in g.month_label.unique()]
        F0, R2 = pF(D2, lab, a, N); c = sum(pF(D2, rperm(rng, lab, blocks), a, N)[0] >= F0 for _ in range(nperm))
        pD = np.nan
        if with_disp:
            J = np.eye(N) - 1.0 / N; w, V = np.linalg.eigh(-0.5 * J @ D2 @ J); pos, neg = w > 1e-10, w < -1e-10
            X, Y = V[:, pos] * np.sqrt(w[pos]), V[:, neg] * np.sqrt(-w[neg]); Fd = dF(X, Y, lab, a, N)
            pD = (1 + sum(dF(X, Y, rperm(rng, lab, blocks), a, N) >= Fd for _ in range(nd))) / (1 + nd)
        rows.append(dict(setting=label, city=city, samples=N, sites=a, R2=R2, p_perm=(1 + c) / (1 + nperm), permdisp_p=pD))
    A = pd.DataFrame(rows)
    if len(A) == 4: A["p_BH"] = bh(A.p_perm.values)
    return A

def analysisBC(s, M, label, seed=SEED):
    rng = np.random.default_rng(seed); rb, rc = [], []
    for (city, mon), g in s.groupby(["city_state", "month_label"]):
        if g.site.nunique() < 2: continue
        cpm = M.loc[g.fileName].values; tot = g.total_reads.values
        pooled = (cpm * tot[:, None] / 1e6).sum(0) / tot.sum() * 1e6; eq = cpm.mean(0)
        t3 = lambda v: set(np.argsort(-v, kind="stable")[:3])
        rb.append(dict(city=city, top3_same=t3(pooled) == t3(eq), rel_L1=np.abs(pooled - eq).sum() / pooled.sum() if pooled.sum() else np.nan,
                       spearman=pd.DataFrame({"a": pooled, "b": eq}).rank().corr().iloc[0, 1]))
    B = pd.DataFrame(rb).groupby("city").agg(city_months=("top3_same", "size"), top3_differ_pct=("top3_same", lambda v: 100 * (1 - v.mean())),
                                              rel_L1_median=("rel_L1", "median"), spearman_median=("spearman", "median")).reset_index(); B.insert(0, "setting", label)
    for city, g0 in s.groupby("city_state"):
        if g0.site.nunique() <= 2: continue
        dist, match = [], []
        for mon, g in g0.groupby("month_label"):
            if len(g) < 3: continue
            cpm = M.loc[g.fileName].values; full = cpm.mean(0)
            if full.sum() == 0: continue
            fp = full / full.sum(); tf = set(np.argsort(-full, kind="stable")[:3])
            for _ in range(NRES):
                sub = cpm[rng.choice(len(g), 2, replace=False)].mean(0)
                if sub.sum() == 0: continue
                dist.append(0.5 * np.abs(sub / sub.sum() - fp).sum()); match.append(set(np.argsort(-sub, kind="stable")[:3]) == tf)
        rc.append(dict(setting=label, city=city, bray_median=np.median(dist), bray_p95=np.percentile(dist, 95), top3_match_rate=np.mean(match)))
    return B, pd.DataFrame(rc)

settings = [("baseline (90% id, >10 CPM)", dict()), ("identity >=95%", dict(idt=95)), ("CPM >5", dict(thr=5)),
            ("CPM >20", dict(thr=20)), ("drop bottom 10% depth", dict(drop_low=True))]
allA, allB, allC = [], [], []
for label, kw in settings:
    s, M = build(**kw); print(label, "| samples", len(s), "| classes", M.shape[1], flush=True)
    allA.append(analysisA(s, M, label)); b, c = analysisBC(s, M, label); allB.append(b); allC.append(c)
s, M = build()
allA.append(analysisA(s, M, "Aitchison distance (zeros -> half min proportion)", metric="aitchison"))
b, c = analysisBC(s, M, "second seed (C only)", seed=SEED2); allC.append(c)
A = pd.concat(allA); B = pd.concat(allB); C = pd.concat(allC)
A.to_csv(OUT + "step4_A_sensitivity.csv", index=False); B.to_csv(OUT + "step4_B_sensitivity.csv", index=False); C.to_csv(OUT + "step4_C_sensitivity.csv", index=False)
# leave-one-site-out (cities with >2 sites)
rows = []
for city, g in s.groupby("city_state"):
    if g.site.nunique() <= 2: continue
    for site in sorted(g.site.unique()):
        s2 = s[s.site != site]; r = analysisA(s2, M, f"drop {site}", nperm=NP_LO, with_disp=False, only_city=city)
        r["dropped_site"] = site; rows.append(r)
LO = pd.concat(rows); LO.to_csv(OUT + "step4_LOSO.csv", index=False)
pd.set_option("display.width", 250)
print("\nA\n", A.round(4).to_string(index=False)); print("\nB\n", B.round(3).to_string(index=False)); print("\nC\n", C.round(3).to_string(index=False))
print("\nLOSO summary\n", LO.groupby("city").agg(R2_min=("R2", "min"), R2_max=("R2", "max"), p_max=("p_perm", "max"), n_drops=("p_perm", "size"), n_p_lt_05=("p_perm", lambda v: (v < .05).sum())).round(4))
