#!/usr/bin/env python3
"""Step 6 - supplementary audit analyses added after review (not part of the frozen protocol; labelled post hoc).
(1) Exact enumeration of all site pairs for Analysis C, with a city-month cluster bootstrap.
(2) PERMANOVA of site given month (month fitted first), permutations of site labels restricted within month.
(3) Mumbai: distance-to-centroid by site, and PERMANOVA/PERMDISP after excluding the most dispersed site.
Usage: python step6_audit_extras.py STEP2_CSV OUT_DIR   (re-uses the data preparation and functions of step 3)"""
import sys, itertools, numpy as np, pandas as pd
IN = sys.argv[1]; OUT = sys.argv[2].rstrip("/") + "/"
src = open(__file__.replace("step6_audit_extras.py", "step3_primary_analysis.py")).read().split("# ---------------- Analysis A")[0]
sys.argv = ["step3", IN, OUT]
ns = {}; exec(compile(src, "step3_head", "exec"), ns)
M, samples, bray, pseudo_F, disp_F, restricted_perm = (ns[k] for k in ["M", "samples", "bray", "pseudo_F", "disp_F", "restricted_perm"])
rng = np.random.default_rng(20261101); ns["rng"] = rng   # separate, documented seed for post hoc analyses
# ---------- (1) Analysis C by exact enumeration + cluster bootstrap over city-months ----------
rows = []
for city in ["Chennai", "Delhi", "Mumbai"]:
    g0 = samples[samples.city_state == city]; per = []
    for mon, g in g0.groupby("month_label"):
        if len(g) < 3: continue
        cpm = M.loc[g.fileName].values; full = cpm.mean(0); fp = full / full.sum(); topf = set(np.argsort(-full, kind="stable")[:3])
        d, m = [], []
        for i, j in itertools.combinations(range(len(g)), 2):
            sub = cpm[[i, j]].mean(0)
            if sub.sum() == 0: continue
            d.append(0.5 * np.abs(sub / sub.sum() - fp).sum()); m.append(set(np.argsort(-sub, kind="stable")[:3]) == topf)
        per.append(dict(n_sites=len(g), pairs=len(d), match=np.mean(m), dists=np.array(d)))
    P = pd.DataFrame(per); k = len(P)
    bm, bd = [], []
    for _ in range(4000):
        ix = rng.integers(0, k, k); bm.append(P.match.values[ix].mean()); bd.append(np.median(np.concatenate([P.dists.values[i] for i in ix])))
    alld = np.concatenate(P.dists.values)
    rows.append(dict(city=city, city_months=k, sites_per_month_min=P.n_sites.min(), sites_per_month_max=P.n_sites.max(), distinct_pairs_total=int(P.pairs.sum()),
                     top3_match_exact=P.match.mean(), top3_ci_lo=np.percentile(bm, 2.5), top3_ci_hi=np.percentile(bm, 97.5),
                     bray_median_exact=np.median(alld), bray_ci_lo=np.percentile(bd, 2.5), bray_ci_hi=np.percentile(bd, 97.5)))
pd.DataFrame(rows).to_csv(OUT + "step6_C_exact_enumeration.csv", index=False)
print(pd.DataFrame(rows).round(3).to_string(index=False))
# ---------- (2) site | month PERMANOVA ----------
def design(lab, mon):
    return np.hstack([np.eye(mon.max() + 1)[mon], np.eye(lab.max() + 1)[lab]])
def proj_ss(X, G):
    Xp = np.linalg.pinv(X); H = X @ Xp; return np.trace(H @ G), np.linalg.matrix_rank(X)
def partial(G, lab, mon, Hm_ss, rm):
    ss_ms, rms = proj_ss(design(lab, mon), G); N = len(lab); tot = np.trace(G)
    ss_site = ss_ms - Hm_ss; res = tot - ss_ms; dfs = rms - rm; dfr = N - rms
    return (ss_site / dfs) / (res / dfr), ss_site / tot, ss_site / (ss_site + res), dfs, dfr
rowsP = []
for city, s in samples[samples.retained].groupby("city_state"):
    s = s.reset_index(drop=True); P = M.loc[s.fileName].values; P = P / P.sum(1, keepdims=True); D2 = bray(P) ** 2; N = len(s)
    J = np.eye(N) - 1 / N; G = -0.5 * J @ D2 @ J
    sites = sorted(s.site.unique()); lab = s.site.map({k: i for i, k in enumerate(sites)}).values
    mu = s.month_label.unique(); mon = s.month_label.map({k: i for i, k in enumerate(mu)}).values
    blocks = [np.where(mon == m)[0] for m in range(len(mu))]
    Xm = np.eye(len(mu))[mon]; ssm, rm = proj_ss(Xm, G)
    F0, R2tot, R2part, dfs, dfr = partial(G, lab, mon, ssm, rm); cnt = 0
    for _ in range(4999):
        Fp = partial(G, restricted_perm(lab, blocks), mon, ssm, rm)[0]; cnt += Fp >= F0
    rowsP.append(dict(city=city, samples=N, month_R2_of_total=ssm / np.trace(G), site_given_month_R2_of_total=R2tot, site_given_month_partial_R2=R2part,
                      pseudo_F=F0, df_site=dfs, df_resid=dfr, p_perm=(1 + cnt) / 5000))
PA = pd.DataFrame(rowsP)
o = np.argsort(PA.p_perm.values); q = PA.p_perm.values[o] * len(PA) / (np.arange(len(PA)) + 1); q = np.minimum.accumulate(q[::-1])[::-1]; adj = np.empty(len(PA)); adj[o] = np.minimum(q, 1)
PA["p_BH"] = adj; PA.to_csv(OUT + "step6_A_site_given_month.csv", index=False); print(PA.round(4).to_string(index=False))
# ---------- (3) Mumbai dispersion by site, and exclusion of the most dispersed site ----------
def mumbai(excl=None):
    s = samples[(samples.city_state == "Mumbai") & samples.retained]
    if excl: s = s[s.site != excl]
    s = s.reset_index(drop=True); P = M.loc[s.fileName].values; P = P / P.sum(1, keepdims=True); D2 = bray(P) ** 2; N = len(s)
    sites = sorted(s.site.unique()); a = len(sites); lab = s.site.map({k: i for i, k in enumerate(sites)}).values
    blocks = [np.where(s.month_label.values == m)[0] for m in s.month_label.unique()]
    F0, R2 = pseudo_F(D2, lab, a, N); cnt = sum(pseudo_F(D2, restricted_perm(lab, blocks), a, N)[0] >= F0 for _ in range(4999))
    J = np.eye(N) - 1 / N; w, V = np.linalg.eigh(-0.5 * J @ D2 @ J); pos, neg = w > 1e-10, w < -1e-10
    X = V[:, pos] * np.sqrt(w[pos]); Y = V[:, neg] * np.sqrt(-w[neg]); Fd = disp_F(X, Y, lab, a, N)
    cd = sum(disp_F(X, Y, restricted_perm(lab, blocks), a, N) >= Fd for _ in range(4999))
    G = np.eye(a)[lab]; n = G.sum(0); C = (G.T @ X) / n[:, None]; Cn = (G.T @ Y) / n[:, None]
    z = np.sqrt(np.abs(((X - G @ C) ** 2).sum(1) - ((Y - G @ Cn) ** 2).sum(1))); zg = (G.T @ z) / n
    return dict(excluded=excl or "none", samples=N, sites=a, R2=R2, p_perm=(1 + cnt) / 5000, permdisp_p=(1 + cd) / 5000), pd.DataFrame(dict(site=sites, n=n.astype(int), mean_dist_to_centroid=zg))
r0, z0 = mumbai(); r1, _ = mumbai("Pratiksha Nagar Wadala")
z0.to_csv(OUT + "step6_Mumbai_dispersion_by_site.csv", index=False); pd.DataFrame([r0, r1]).to_csv(OUT + "step6_Mumbai_exclusion.csv", index=False)
print(z0.round(3).to_string(index=False)); print(pd.DataFrame([r0, r1]).round(4).to_string(index=False))
