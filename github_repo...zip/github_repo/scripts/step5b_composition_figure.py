#!/usr/bin/env python3
"""Step 5b - Figure 3: mean drug-class composition by site within each city (retained samples only)."""
import sys, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
CPM = sys.argv[1]; OUT = sys.argv[2].rstrip("/") + "/"
x = pd.read_csv(CPM, usecols=["fileName","Drug Class","cpm","detected","city_state","site"])
S = x.drop_duplicates("fileName")[["fileName","city_state","site"]].reset_index(drop=True)
S["site"] = S.site.replace({"Kj Somaiya Ghatkopar": "KJ Somaiya Ghatkopar", "Lbs Marg, Bhandup": "LBS Marg, Bhandup"})
d = x[x.detected].copy(); d["cls"] = np.where(d["Drug Class"].str.contains(";"), "multidrug", d["Drug Class"]).astype(object)
d["cls"] = d["cls"].str.replace(" antibiotic", "", regex=False)
M = d.groupby(["fileName","cls"])["cpm"].sum().unstack(fill_value=0.0).reindex(S.fileName).fillna(0.0)
keep = M.sum(axis=1).values > 0; S, M = S[keep].reset_index(drop=True), M[keep]
P = M.div(M.sum(axis=1), axis=0); top = list(P.mean().sort_values(ascending=False).index[:7])
P2 = P[top].copy(); P2["other"] = 1 - P2.sum(axis=1)
pal = ["#0072B2","#E69F00","#009E73","#D55E00","#CC79A7","#56B4E9","#F0E442","#999999"]
cities = ["Chennai","Delhi","Kolkata","Mumbai"]
fig, axs = plt.subplots(4, 1, figsize=(7.5, 8.6), gridspec_kw={"height_ratios": [5, 4, 2, 8]})
for ax, c in zip(axs, cities):
    g = S[S.city_state == c]; sites = sorted(g.site.unique()); mean = P2.loc[g.fileName.values].groupby(g.site.values).mean().loc[sites]; n = g.groupby("site").size().loc[sites]
    left = np.zeros(len(sites))
    for k, col in enumerate(P2.columns): ax.barh(range(len(sites)), mean[col].values, left=left, color=pal[k], label=col, edgecolor="white", linewidth=.4); left += mean[col].values
    ax.set_yticks(range(len(sites))); ax.set_yticklabels([f"{s} (n={n[s]})" for s in sites], fontsize=7); ax.invert_yaxis(); ax.set_xlim(0, 1)
    ax.set_title(c, loc="left", fontsize=9, fontweight="bold"); ax.spines[["top","right"]].set_visible(False)
axs[-1].set_xlabel("Mean proportion of detected ARG CPM per sample")
axs[0].legend(ncol=4, fontsize=6.5, frameon=False, loc="lower center", bbox_to_anchor=(0.5, 1.18))
plt.tight_layout(); plt.savefig(OUT + "Fig3_site_composition.png", dpi=200); plt.savefig(OUT + "Fig3_site_composition.pdf"); plt.close()
print("top classes:", top)
