# Data provenance and audit

How the 447 samples and the site key were obtained and checked. Nothing in the original data was modified.

## Inputs

| Input | Source |
|---|---|
| Processed tables | Zenodo archive `data.tar.xz`, doi:10.5281/zenodo.17590646 (MD5 `dd9e8bfaaad2aa5b33c81c7fd1a8b5bc`, verified) |
| Original analysis code | GitHub `SowpatiLab/Metro_metagenomics`; Zenodo record 18465564 |
| Sample-to-site key | NCBI BioProject PRJNA1415085, SRA run table, `location` field |

## Why the site key had to be reconstructed

- `meta.tsv` in the archive holds city and month for each of the 447 samples but no site column.
- The paper's Supplementary Data 1 to 7 were checked: Supplementary Data 7 lists the 19 sites with coordinates but does not map samples to sites; the Source Data files are at city-month or assembled-genome level.
- The NCBI run table for PRJNA1415085 records a location (19 distinct sites) for every run, and its sample names match the archive's sample codes.

## Checks performed

- 447 of 447 sample codes matched between the archive and the run table.
- City and month agreed between the two sources for every sample.
- No duplicate sample codes; at most one sample per site-month.
- Sites per city: Kolkata 2, Delhi 4, Chennai 5, Mumbai 8 (19 in total).
- The original code's pooled city-month filtering was reproduced exactly (3,402 rows, 166 ARGs), which validates the CPM denominator and filters.

## Limitations of the key

- BioSample latitude/longitude fields are empty for all samples; coordinates exist only in the paper's Supplementary Data 7.
- Site names were standardised only for letter case (for example "KJ Somaiya Ghatkopar", "LBS Marg, Bhandup").
- The design is unbalanced (Chennai has no samples for January to March 2024, Mumbai none for July 2022, a few other site-months are missing) and Kolkata has two sites.

## Output

`tables/master_sample_site_map.csv`: one row per sample (sample code, site, city, month, SRA run, BioSample).

`scripts/step1_audit.py INPUT_DIR OUTPUT_DIR` reruns the integrity audit on unmodified downloads and writes a QC report and a file manifest with SHA-256 checksums.
