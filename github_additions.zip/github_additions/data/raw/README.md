# data/raw

Put the downloaded input files here. They are not stored in this repository.

Required: `meta.tsv`, `rgi_bowtie.tsv`, `bacterial_read_df.tsv` (from the original authors' archive, Zenodo doi:10.5281/zenodo.17590646; archive MD5 `dd9e8bfaaad2aa5b33c81c7fd1a8b5bc`).

The Colab notebook downloads and extracts the archive here automatically.
